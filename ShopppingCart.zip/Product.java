package com;

public class Product {
    String pid,name;
    int price,noof;
	public Product(String pid1,String name1,int price1,int noof1)
	{    
       pid=pid1;
       name=name1;
       price=price1;
       noof=noof1;
   	}
	public void setpid(String pid){}
	public String getpid()
	{
		return pid;
	}
	public void setname(String name){}
	public String getname()
	{
		return name;
	}
    public void setprice(int price){}
    public int getprice()
    {
    	return price;
    }
    public void setnoof(int noof){}
    public int getnoof()
    {
    	return noof;
    }
}
