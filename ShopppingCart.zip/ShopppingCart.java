package com;
import java.util.*;
public class ShopppingCart {

	public static void main(String[] args) 
	{
		ArrayList<Product> cart=new ArrayList<Product>();
        Product p1=new Product("p1001","Mobile",9000,3);
        Product p2=new Product("p1002","Mp3 player",3000,2);
        Product p3=new Product("p1003","Shirt",1500,3);
        cart.add(p1);
        cart.add(p2);
        cart.add(p3);
        for(Product p:cart)
        {
        	System.out.println("product id:"+p.getpid());
        	System.out.println("product name:"+p.getname());
        	System.out.println("price:"+p.getprice());
        	System.out.println("no products:"+p.getnoof());
        }
	}

}
