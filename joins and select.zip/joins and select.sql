create table course1
(
stcourseid Varchar(25) PRIMARY KEY,
cname Varchar(50),
cfee int,
cduration int,
);
create table student
(
stid int NOT NULL Primary key,
stname Varchar(25),
stage int NOT NULL,
staddress Varchar(100),
stmarks int,
stcourseid Varchar(25) FOREIGN KEY REFERENCES course1(stcourseid)
)

select * from student;
select * from course1;

select student.stname,student.stmarks,course1.cname
from student,course1
where student.stcourseid=course1.stcourseid;

insert into course1(stcourseid,cname,cfee,cduration)
values('s7207001','devops',30000,45),
('s7207056','core java',15000,35),
('s7207031','sql',10000,25)

insert into student(stid,stname,stage,staddress,stmarks,stcourseid)
values (01,'Karthick',20,'2/281 rajaji st chennai',82,'s7207001'),
(02,'Vignesh',20,'464 thiruvattar kanyakumari',90,'s7207056'),
(03,'Neiha',20,'281 RS puram coimbatore',85,'s7207031')